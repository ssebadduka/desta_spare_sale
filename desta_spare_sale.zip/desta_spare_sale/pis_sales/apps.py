# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class PisSalesConfig(AppConfig):
    name = 'pis_sales'
